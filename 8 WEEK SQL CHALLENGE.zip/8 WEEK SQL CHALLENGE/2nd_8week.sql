CREATE SCHEMA pizza_runner;
SET search_path = pizza_runner;

DROP TABLE IF EXISTS runners;
CREATE TABLE runners (
  "runner_id" INTEGER,
  "registration_date" DATE
);
INSERT INTO runners
  ("runner_id", "registration_date")
VALUES
  (1, '2021-01-01'),
  (2, '2021-01-03'),
  (3, '2021-01-08'),
  (4, '2021-01-15');


DROP TABLE IF EXISTS customer_orders;
CREATE TABLE customer_orders (
  "order_id" INTEGER,
  "customer_id" INTEGER,
  "pizza_id" INTEGER,
  "exclusions" VARCHAR(4),
  "extras" VARCHAR(4),
  "order_time" TIMESTAMP
);

INSERT INTO customer_orders
  ("order_id", "customer_id", "pizza_id", "exclusions", "extras", "order_time")
VALUES
  ('1', '101', '1', '', '', '2020-01-01 18:05:02'),
  ('2', '101', '1', '', '', '2020-01-01 19:00:52'),
  ('3', '102', '1', '', '', '2020-01-02 23:51:23'),
  ('3', '102', '2', '', NULL, '2020-01-02 23:51:23'),
  ('4', '103', '1', '4', '', '2020-01-04 13:23:46'),
  ('4', '103', '1', '4', '', '2020-01-04 13:23:46'),
  ('4', '103', '2', '4', '', '2020-01-04 13:23:46'),
  ('5', '104', '1', 'null', '1', '2020-01-08 21:00:29'),
  ('6', '101', '2', 'null', 'null', '2020-01-08 21:03:13'),
  ('7', '105', '2', 'null', '1', '20
WHERE visit_id IN20-01-08 21:20:29'),
  ('8', '102', '1', 'null', 'null', '2020-01-09 23:54:33'),
  ('9', '103', '1', '4', '1, 5', '2020-01-10 11:22:59'),
  ('10', '104', '1', 'null', 'null', '2020-01-11 18:34:49'),
  ('10', '104', '1', '2, 6', '1, 4', '2020-01-11 18:34:49');


DROP TABLE IF EXISTS runner_orders;
CREATE TABLE runner_orders (
  "order_id" INTEGER,
  "runner_id" INTEGER,
  "pickup_time" VARCHAR(19),
  "distance" VARCHAR(7),
  "duration" VARCHAR(10),
  "cancellation" VARCHAR(23)
);

INSERT INTO runner_orders
  ("order_id", "runner_id", "pickup_time", "distance", "duration", "cancellation")
VALUES
  ('1', '1', '2020-01-01 18:15:34', '20km', '32 minutes', ''),
  ('2', '1', '2020-01-01 19:10:54', '20km', '27 minutes', ''),
  ('3', '1', '2020-01-03 00:12:37', '13.4km', '20 mins', NULL),
  ('4', '2', '2020-01-04 13:53:03', '23.4', '40', NULL),
  ('5', '3', '2020-01-08 21:10:57', '10', '15', NULL),
  ('6', '3', 'null', 'null', 'null', 'Restaurant Cancellation'),
  ('7', '2', '2020-01-08 21:30:45', '25km', '25mins', 'null'),
  ('8', '2', '2020-01-10 00:15:02', '23.4 km', '15 minute', 'null'),
  ('9', '2', 'null', 'null', 'null', 'Customer Cancellation'),
  ('10', '1', '2020-01-11 18:50:20', '10km', '10minutes', 'null');


DROP TABLE IF EXISTS pizza_names;
CREATE TABLE pizza_names (
  "pizza_id" INTEGER,
  "pizza_name" TEXT
);
INSERT INTO pizza_names
  ("pizza_id", "pizza_name")
VALUES
  (1, 'Meatlovers'),
  (2, 'Vegetarian');


DROP TABLE IF EXISTS pizza_recipes;
CREATE TABLE pizza_recipes (
  "pizza_id" INTEGER,
  "toppings" TEXT
);
INSERT INTO pizza_recipes
  ("pizza_id", "toppings")
VALUES
  (1, '1, 2, 3, 4, 5, 6, 8, 10'),
  (2, '4, 6, 7, 9, 11, 12');


DROP TABLE IF EXISTS pizza_toppings;
CREATE TABLE pizza_toppings (
  "topping_id" INTEGER,
  "topping_name" TEXT
);
INSERT INTO pizza_toppings
  ("topping_id", "topping_name")
VALUES
  (1, 'Bacon'),
  (2, 'BBQ Sauce'),
  (3, 'Beef'),
  (4, 'Cheese'),
  (5, 'Chicken'),
  (6, 'Mushrooms'),
  (7, 'Onions'),
  (8, 'Pepperoni'),
  (9, 'Peppers'),
  (10, 'Salami'),
  (11, 'Tomatoes'),
  (12, 'Tomato Sauce');
  
---(1)-How many pizzas were ordered?-------------------------------------------------------------------------------------------------------------------------------
select count(order_id)
from customer_orders;
---(2)-How many unique customer orders were made?-------------------------------------------------------------------------------------------------------------------------------
select count(distinct customer_id)
from customer_orders;
---(3)-How many successful orders were delivered by each runner?-------------------------------------------------------------------------------------------------------------------------------
select runner_id,
count(order_id) as successful_or
from runner_orders
where duration is not NULL
group by runner_id
order by runner_id;


---(4)-How many of each type of pizza was delivered?-------------------------------------------------------------------------------------------------------------------------------
select pizza_name,count(pizza_name)
from customer_orders 
join runner_orders on customer_orders.order_id = runner_orders.order_id
join pizza_names on customer_orders.pizza_id = pizza_names.pizza_id
where distance is not null
group by pizza_name;
---(5)-How many Vegetarian and Meatlovers were ordered by each customer?-------------------------------------------------------------------------------------------------------------------------------
select customer_id, pizza_name, count(pizza_name) as ordered_pizza
from customer_orders 
join pizza_names on customer_orders.pizza_id = pizza_names.pizza_id
group by customer_id,pizza_name
order by customer_id;
---(6)-What was the maximum number of pizzas delivered in a single order?-------------------------------------------------------------------------------------------------------------------------------
select c.order_id,count(c.pizza_id)
from customer_orders c
join runner_orders r on c.order_id=r.order_id
where distance is not null
group by c.order_id
order by count(c.pizza_id) desc
limit 1;
---(7)-For each customer, how many delivered pizzas had at least 1 change and how many had no changes?-------------------------------------------------------------------------------------------------------------------------------
select customer_id,
sum(case when exclusions != '' or extras != '' then 1 else 0 end) as at_least_one_change,
sum(case when exclusions = '' and extras = '' then 1 else 0 end) as no_changes
from customer_orders c
join runner_orders r on c.order_id = r.order_id
where r.duration != ''
group by customer_id
order by customer_id;

--(8)--How many pizzas were delivered that had both exclusions and extras?--------------------------------------------------------
select c.order_id, 
sum(case when exclusions != '' and extras  != '' then 1 else 0 end) as both_extras_exclusions
from customer_orders c
join runner_orders r on c.order_id = r.order_id
group by c.order_id
order by c.order_id;

--(9)--What was the total volume of pizzas ordered for each hour of the day?--------------------------------------------------------
select date_part('hour',order_time) as hour, date_part('day',order_time) as day,count(order_id) 
from customer_orders 
group by date_part('hour',order_time), date_part('day',order_time);
--(10)--What was the volume of orders for each day of the week?--------------------------------------------------------
select date_part('day',order_time), date_part('week',order_time),count(order_id) 
from customer_orders 
group by date_part('day',order_time), date_part('week',order_time);




 








select (REGEXP_REPLACE('ABC123ABC','[[:alpha:]]','','g')::NUMERIC(10,2))



--(1)--How many runners signed up for each 1 week period? (i.e. week starts 2021-01-01)--------------------------------------------------------


select (case when EXTRACT('day' from registration_date) between 1 and 6 then 1 
			when EXTRACT('day' from registration_date) between 7 and 14 then 2 
			when EXTRACT('day' from registration_date) between 15 and 21 then 3 
			when EXTRACT('day' from registration_date) = 22 then 28 end) as weeks, count(*) from runners group by weeks order by weeks;
			
--(2)--What was the average time in minutes it took for each runner to arrive at the Pizza Runner HQ to pickup the order?--------------------------------------------------------

SELECT runner_id, 
  avg(date_part('minute',(r.pickup_time::TIMESTAMP -c.order_time)))as avg_arrival_time 
from customer_orders c
join runner_orders r on c.order_id=r.order_id
where pickup_time != 'null'
group by runner_id;

--(3)--Is there any relationship between the number of pizzas and how long the order takes to prepare?--------------------------------------------------------
SELECT c.order_id,count(c.order_id) as number_of_pizzas, date_part('minute',(r.pickup_time::TIMESTAMP -c.order_time)) as preperation_time
from customer_orders c
join runner_orders r on c.order_id=r.order_id
where pickup_time != 'null'
group by c.order_id,r.pickup_time, c.order_time
order by c.order_id;

--(4)--What was the average distance travelled for each customer?--------------------------------------------------------
select customer_id, avg((REGEXP_REPLACE(distance,'[[:alpha:]]','','g')::NUMERIC(10,2))) avg_distance
from customer_orders c
join runner_orders r on c.order_id=r.order_id
where r.distance != 'null'
group by customer_id
order by customer_id;

---(5)--What was the difference between the longest and shortest delivery times for all orders?-------------------------
select 
MAX((REGEXP_REPLACE(duration,'[[:alpha:]]','','g')::NUMERIC)) 
- 
MIN((REGEXP_REPLACE(duration,'[[:alpha:]]','','g')::NUMERIC)) as difference
from runner_orders
where duration != 'null';

---(6)--What was the average speed for each runner for each delivery and do you notice any trend for these values?-------------------------

with km_hour as(
select *, (REGEXP_REPLACE(distance,'[[:alpha:]]','','g')::NUMERIC) as kilometers, 
(REGEXP_REPLACE(duration,'[[:alpha:]]','','g')::NUMERIC/60) as hours from runner_orders)

select order_id, runner_id,round(kilometers/hours,2) as avg_speed_km_per_hour
from km_hour
where distance != 'null' and duration !='null'
group by order_id, runner_id, avg_speed_km_per_hour
order by order_id;

---(7)--What is the successful delivery percentage for each runner?-------------------------

select runner_id, round(sum(successfull)/count(*)*100,0)||'%' as succ_percentage from
(select runner_id,
case when duration!='null' then count(*)
	else 0 end as successfull,
case when duration='null' then count(*)
	else 0 end as unsuccessfull
from runner_orders
group by runner_id, duration)k
group by runner_id
order by runner_id;



--(1)--What are the standard ingredients for each pizza?--------------------------------------------------------
with cte as(
	select pizza_id,
	CAST(unnest(string_to_array(toppings,',')) as INT) as topping_id 
	from pizza_recipes) 
select pn.pizza_id, pn.pizza_name,pt.topping_id, pt.topping_name 
from pizza_names pn 
join cte on cte.pizza_id= pn.pizza_id
join pizza_toppings pt on cte.topping_id = pt.topping_id
order by topping_id;

--(2)--What was the most commonly added extra?--------------------------------------------------------

with extras_cte as(select  pizza_id,
	CAST(unnest(string_to_array(extras,',')) as INT) as extras 
	from customer_orders
	where extras not in ('null','NaN'))
select topping_name,count(extras) 
from extras_cte ec
join pizza_toppings pt on ec.extras=pt.topping_id
group by extras, topping_name
order by extras;

--(3)--What was the most common exclusion?--------------------------------------------------------
with exclusions_cte as(select  pizza_id,
	CAST(unnest(string_to_array(exclusions,',')) as INT) as exclusions 
	from customer_orders
	where exclusions !='null')
select topping_name,count(exclusions) 
from exclusions_cte ec
join pizza_toppings pt on ec.exclusions=pt.topping_id
group by exclusions, topping_name
order by exclusions;

--(4)--Generate an order item for each record in the customers_orders table in the format of one of the following:
-- Meat Lovers
-- Meat Lovers - Exclude Beef
-- Meat Lovers - Extra Bacon
-- Meat Lovers - Exclude Cheese, Bacon - Extra Mushroom, Peppers--------------------------------------------------------
SELECT
  order_id,
  CONCAT(
    pizza_name,
    ' ',
    CASE
      WHEN COUNT(exclusions) > 0 THEN '- Exclude '
      ELSE ''
    END,
    STRING_AGG(exclusions, ', '),
    CASE
      WHEN COUNT(extras) > 0 THEN ' - Extra '
      ELSE ''
    END,
    STRING_AGG(extras, ', ')
  ) AS pizza_name_exclusions_and_extras
FROM
  (
    WITH rank_added AS (
      SELECT
        *,
        ROW_NUMBER() OVER () AS rank
      FROM
        pizza_runner.customer_orders
    )
    SELECT
      rank,
WHERE visit_id IN
      ra.order_id,
      pizza_name,
      CASE
        WHEN exclusions != 'null'
        AND topping_id IN (
          SELECT
            UNNEST(STRING_TO_ARRAY(exclusions, ',') :: int [])
        ) THEN topping_name
      END AS exclusions,
      CASE
        WHEN extras != 'null'
        AND topping_id IN (
          SELECT
            unnest(string_to_array(extras, ',') :: int [])
        ) THEN topping_name
      END AS extras
    FROM
      pizza_runner.pizza_toppings AS t,
      rank_added as ra
      JOIN pizza_runner.pizza_names AS n ON ra.pizza_id = n.pizza_id
    GROUP BY
      rank,
      ra.order_id,
      pizza_name,
      exclusions,
      extras,
      topping_id,
      topping_name
  ) AS toppings_as_names
GROUP BY
  pizza_name,
  rank,
  order_id
ORDER BY
  rank


--(5)--Generate an alphabetically ordered comma separated ingredient list for each pizza order from the customer_orders table and add a 2x in front of any relevant ingredients
-- For example: "Meat Lovers: 2xBacon, Beef, ... , Salami"--------------------------------------------------------
SELECT
  order_id,
  CONCAT(
    pizza_name,
    ': ',
    STRING_AGG(
      topping_name,
      ', '
      ORDER BY
        topping_name
    )
  ) AS all_ingredients
FROM
  (
    SELECT
      rank,
      order_id,
      pizza_name,
      CONCAT(
        CASE
          WHEN (SUM(count_toppings) + SUM(count_extra)) > 1 THEN (SUM(count_toppings) + SUM(count_extra)) || 'x'
        END,
        topping_name
      ) AS topping_name
    FROM
      (
        WITH rank_added AS (
          SELECT
            *,
            ROW_NUMBER() OVER () AS rank
          FROM
            pizza_runner.customer_orders
        )
        SELECT
          rank,
          ra.order_id,
          pizza_name,
          topping_name,
          CASE
            WHEN exclusions != 'null'
            AND t.topping_id IN (
              SELECT
                unnest(string_to_array(exclusions, ',') :: int [])
            ) THEN 0
            ELSE CASE
              WHEN t.topping_id IN (
                SELECT
                  UNNEST(STRING_TO_ARRAY(r.toppings, ',') :: int [])
              ) THEN COUNT(topping_name)
              ELSE 0
            END
          END AS count_toppings,
          CASE
            WHEN extras != 'null'
            AND t.topping_id IN (
              SELECT
                unnest(string_to_array(extras, ',') :: int [])
            ) THEN count(topping_name)
            ELSE 0
          END AS count_extra
        FROM
          rank_added AS ra,
          pizza_runner.pizza_toppings AS t,
          pizza_runner.pizza_recipes AS r
          JOIN pizza_runner.pizza_names AS n ON r.pizza_id = n.pizza_id
        WHERE
          ra.pizza_id = n.pizza_id
        GROUP BY
          pizza_name,
          rank,
          ra.order_id,
          topping_name,
          toppings,
          exclusions,
          extras,
          t.topping_id
      ) tt
    WHERE
      count_toppings > 0
      OR count_extra > 0
    GROUP BY
      pizza_name,
      rank,
      order_id,
      topping_name
  ) cc
GROUP BY
  pizza_name,
  rank,
  order_id
ORDER BY
  rank


--(6)--What is the total quantity of each ingredient used in all delivered pizzas sorted by most frequent first?--------------------------------------------------------


 SELECT
  topping_name,
  (SUM(topping_count) + SUM(extras_count)) AS total_ingredients
FROM
  (
    WITH rank_added AS (
      SELECT
        *,
        ROW_NUMBER() OVER () AS rank
      FROM
        pizza_runner.customer_orders
    )
    SELECT
      rank,
      topping_name,
      CASE
        WHEN extras != 'null'
        AND topping_id IN (
          SELECT
            unnest(string_to_array(extras, ',') :: int [])
        ) THEN count(topping_name)
        ELSE 0 END AS extras_count,
      CASE
        WHEN exclusions != 'null'
        AND topping_id IN (
          SELECT
            unnest(string_to_array(exclusions, ',') :: int [])
        ) THEN NULL
        ELSE 
	  CASE
          WHEN topping_id IN (
            SELECT
              UNNEST(STRING_TO_ARRAY(toppings, ',') :: int [])
          ) THEN COUNT(topping_name)
        END
      END AS topping_count
    FROM
      pizza_runner.pizza_toppings AS t,
      pizza_runner.pizza_recipes AS r,
      rank_added as ra,
      pizza_runner.runner_orders AS ro
    WHERE
      ro.order_id = ra.order_id
      and ra.pizza_id = r.pizza_id
      and pickup_time != 'null'
      AND distance != 'null'
      AND duration != 'null'
    GROUP BY
      topping_name,
      exclusions,
      extras,
      toppings,
      topping_id,
      rank
  ) AS topping_count
GROUP BY
  topping_name
ORDER BY
  total_ingredients DESC
  
  
  
  
--(1)--If a Meat Lovers pizza costs $12 and Vegetarian costs $10 and there were no charges for changes - how much money has Pizza Runner made so far if there are no delivery fees?-----
select runner_id, sum(case when pizza_id=1 then 12 else 10 end)||' $' as earning
from runner_orders
join customer_orders using( order_id)
where distance != 'null'
group by runner_id
order by runner_id;




----2. What if there was an additional $1 charge for any pizza extras?
with base_price_cte as (
	select runner_id,
	sum(case when pizza_id =1 then 12 
		else 10 	
		end) as base_price
	from customer_orders co
	join runner_orders ro on co.order_id=ro.order_id
	where duration != 'null'
   group by ro.runner_id),


  extra_price_cte as (
	select count(topping_id) as extra_price
	from (
	select
		cast(unnest(string_to_array(extras,',')) as int) as topping_id
		from customer_orders co
	join runner_orders ro on co.order_id=ro.order_id
	where duration != 'null'
	)k
)

select runner_id,sum(base_price)+ extra_price as total_price
from base_price_cte, extra_price_cte
group by runner_id,extra_price
order by runner_id;


---3. The Pizza Runner team now wants to add an additional ratings system that allows customers to rate their runner, how would you design an additional table for this new dataset - generate a schema for this new table and insert your own data for ratings for each successful customer order between 1 to 5.


SET search_path = pizza_runner;
DROP TABLE IF EXISTS runner_rating;
CREATE TABLE runner_rating (
    "id" SERIAL PRIMARY KEY,
    "order_id" INTEGER,
    "customer_id" INTEGER,
    "runner_id" INTEGER,
    "rating" INTEGER,
    "rating_time" TIMESTAMP
  );
INSERT INTO
  runner_rating (
    "order_id",
    "customer_id",
    "runner_id",
    "rating",
    "rating_time"
  )
VALUES
  ('1', '101', '1', '5', '2020-01-01 19:34:51'),
  ('2', '101', '1', '5', '2020-01-01 20:23:03'),
  ('3', '102', '1', '4', '2020-01-03 10:12:58'),
  ('4', '103', '2', '5', '2020-01-04 16:47:06'),
  ('5', '104', '3', '5', '2020-01-08 23:09:27'),
  ('7', '105', '2', '4', '2020-01-08 23:50:12'),
  ('8', '102', '2', '4', '2020-01-10 12:30:45'),
  ('10', '104', '1', '5', '2020-01-11 20:05:35');
  
 select * from runner_rating;


----4. Using your newly generated table - can you join all of the information together to form a table which has the following information for successful deliveries?
-- customer_id
-- order_id
-- runner_id
-- rating
-- order_time
-- pickup_time
-- Time between order and pickup
-- Delivery duration
-- Average speed
-- Total number of pizzas
select co.customer_id,
	   ro.order_id,
	   ro.runner_id,
	   rr.rating,
	   co.order_time,
	   pickup_time,
	   ROUND(date_part('minute',(pickup_time::TIMESTAMP -co.order_time))) AS time_between_order_and_pickup,
	   (REGEXP_REPLACE(duration,'[[:alpha:]]','','g')::NUMERIC) AS delivery_duration,
	   round((REGEXP_REPLACE(distance,'[[:alpha:]]','','g')::NUMERIC)/(REGEXP_REPLACE(duration,'[[:alpha:]]','','g')::NUMERIC/60),2) as avg_speed_km_per_hour,
	   count(co.order_id) as num_pizzas
FROM
  runner_orders as ro
  JOIN runner_rating as rr on ro.order_id = rr.order_id
  JOIN customer_orders as co on ro.order_id = co.order_id
GROUP BY
  co.customer_id,
  ro.order_id,
  ro.runner_id,
  rating,
  order_time,
  pickup_time,
  duration,
 ro.distance
  ORDER BY co.customer_id;
	   
	   
---5. If a Meat Lovers pizza was $12 and Vegetarian $10 fixed prices with no cost for extras and each runner is paid $0.30 per kilometre traveled - how much money does Pizza Runner have left over after these deliveries?
select runner_id, round(sum(
	 (case when pizza_id=1 then 12 else 10 end)+
	 ((REGEXP_REPLACE(distance,'[[:alpha:]]','','g')::NUMERIC(10,2)) * 0.30)),2)||' $' as earning
from runner_orders
join customer_orders using( order_id)
where distance != 'null'
group by runner_id;

	   
-----BONUS------If Danny wants to expand his range of pizzas - how would this impact the existing data design? Write an INSERT statement to demonstrate what would happen if a new Supreme pizza with all the toppings was added to the Pizza Runner menu?
insert into pizza_names (pizza_id, pizza_name)
values
  (3, 'Supreme');
insert into
  pizza_recipes (pizza_id, toppings)
values
  (3, '1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12');
 
 select * from pizza_names;
 select * from pizza_recipes;

 
